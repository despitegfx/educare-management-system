<?php

if(!isset($_SESSION['user_name'])){
echo '<script type="text/javascript">window.location="login.php"; </script>';
}



?>