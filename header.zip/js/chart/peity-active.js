(function ($) {
 "use strict";
	
    $(".bar").peity("bar", {
        fill: ["#0d4cff", "#d7d7d7"]
    })

	
})(jQuery); 